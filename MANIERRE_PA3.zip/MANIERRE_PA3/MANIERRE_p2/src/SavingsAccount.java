public class SavingsAccount {

    private static double annualInterestRate;
    private static double savingsBalance;

    public static void inputAnnualInterestRate(double setAnnualInterestRate) {
        annualInterestRate = setAnnualInterestRate;
    }

    public static void inputSavingsBalance(double setSavingsBalance) {
        savingsBalance = setSavingsBalance;
    }

    public static void calculateMonthlyInterest() {
        int i;
        double monthlyInterest;

        for (i = 1; i < 13; i++) {
            monthlyInterest = (savingsBalance * annualInterestRate) / 12;
            savingsBalance = savingsBalance + monthlyInterest;
            System.out.print("For month number " + i + " account Balance is: $");
            System.out.printf("%.2f\n", savingsBalance);
        }
    }

    public static void modifyInterestRate(double newAnnualInterestRate) {
        annualInterestRate = newAnnualInterestRate;
    }

}

