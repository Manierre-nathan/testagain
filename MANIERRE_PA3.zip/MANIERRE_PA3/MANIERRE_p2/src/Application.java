public class Application {

    public static void main(String[] args) {

        SavingsAccount saver1 = new SavingsAccount();
        SavingsAccount saver2 = new SavingsAccount();

        // saver1

        System.out.println("Balances for account saver1 at an annual interest rate of 4%\n");

        saver1.inputSavingsBalance(2000.00);
        saver1.inputAnnualInterestRate(.04);
        saver1.calculateMonthlyInterest();

        System.out.println("\nBalances for account saver1 at an annual interest rate of 5%\n");

        saver1.inputSavingsBalance(2000.00);
        saver1.modifyInterestRate(.05);
        saver1.calculateMonthlyInterest();


        // saver2

        System.out.println("\nBalances for account saver2 at an annual interest rate of 4%\n");
        saver2.inputSavingsBalance(3000.00);
        saver2.inputAnnualInterestRate(.04);
        saver2.calculateMonthlyInterest();

        System.out.println("\nBalances for account saver2 at an annual interest rate of 5%\n");

        saver2.inputSavingsBalance(3000.00);
        saver2.modifyInterestRate(.05);
        saver2.calculateMonthlyInterest();

    }


}
