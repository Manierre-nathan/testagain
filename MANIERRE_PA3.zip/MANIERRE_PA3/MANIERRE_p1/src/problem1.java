import java.security.SecureRandom;
import java.util.Scanner;


public class problem1 {


    private static double questionGenerator(int digitBound, int probType) {
        SecureRandom randNum = new SecureRandom();


        int digit1;
        int digit2;
        int answer = 0;

        digit1 = randNum.nextInt(digitBound);
        digit2 = randNum.nextInt(digitBound);

        if(probType == 1){
            System.out.println("How much is " + digit1 + " plus " + digit2 + "?");
            answer = digit1 + digit2;
        }

        if(probType == 2){
            System.out.println("How much is " + digit1 + " times " + digit2 + "?");
            answer = digit1 * digit2;
        }

        if(probType == 3){
            System.out.println("How much is " + digit1 + " minus " + digit2 + "?");
            answer = digit1 - digit2;
        }

        if(probType == 4){
            while(digit2 == 0)
                digit2 = randNum.nextInt(digitBound);
            System.out.println("How much is " + digit1 + " divided by " + digit2 + "?");
            answer = digit1 / digit2;
        }



        return answer;
    }

    private static int difficultyGenerator(){
        int difficulty;
        int digitNum = 0;
        Scanner scnr = new Scanner(System.in);
        System.out.println("Enter either 1, 2, 3, or 4 for the desired question difficulty");

        difficulty = scnr.nextInt();

        if(difficulty == 1){
            digitNum = 10;
        }
        if(difficulty == 2){
            digitNum = 100;
        }
        if(difficulty == 3){
            digitNum = 1000;
        }
        if(difficulty == 4){
            digitNum = 10000;
        }

        return digitNum;

    }

    private static int problemTypeDeterminer(){
        Scanner scnr = new Scanner(System.in);

        int problemType;

        System.out.println("\nSelect a problem type...");
        System.out.println("Enter 1 for addition, 2 for multiplication, 3 for subtraction, ");
        System.out.println("4 for division, or 5 for a random mixture of problems");

        problemType = scnr.nextInt();

        return problemType;

    }



    private static void responseGenerator(int correctVal) {
        // correctVal  value is 1 if correct, 0 if incorrect
        SecureRandom randNum = new SecureRandom();

        int responseCase = randNum.nextInt(4);

        if (correctVal == 0) {


            switch (responseCase) {
                case 0:
                    System.out.println("No. Please try again.");
                    break;
                case 1:
                    System.out.println("Wrong. Try once more.");
                    break;
                case 2:
                    System.out.println("Don’t give up!");
                    break;
                case 3:
                    System.out.println("No. Keep trying.");
                    break;
            }


        }

        if (correctVal == 1) {


            responseCase = randNum.nextInt(4);

            switch (responseCase) {
                case 0:
                    System.out.println("Very good!");
                    break;
                case 1:
                    System.out.println("Excellent!");
                    break;
                case 2:
                    System.out.println("Nice work!");
                    break;
                case 3:
                    System.out.println("Keep up the good work!");
                    break;
            }
        }
    }


    public static void main(String[] args) {

        Scanner scnr = new Scanner(System.in);
        SecureRandom randNum = new SecureRandom();

        int i;
        int cont = 1;
        int digitBound;
        int problemType;
        int mixture = 0;
        int correctNum = 0;
        int wrongNum = 0;
        int percentCorrect;
        double qAnswer;
        double userAns;


        while(cont ==  1){

            System.out.println("\nWelcome to multiplication practice!\n\n");

            digitBound = difficultyGenerator();
            problemType = problemTypeDeterminer();

            if(problemType == 5)
                mixture = 1;



            for (i = 0; i < 10; i++) {

                if(mixture == 1){
                    problemType = randNum.nextInt(4) +1;
                    System.out.println("problem type = " + problemType);
                }

                qAnswer = questionGenerator(digitBound, problemType );
                userAns = scnr.nextDouble();

                if (userAns == qAnswer) {               // correct case
                    correctNum++;
                    responseGenerator(1);
                }
                if (userAns != qAnswer) {          // incorrect case
                    wrongNum++;
                    responseGenerator(0);
                }

            }



            System.out.println("\nNumber of questions answered correctly: " + correctNum);
            System.out.println("Number of questions answered incorrectly: " + wrongNum);

            percentCorrect = (correctNum / 10) * 100;
            if (percentCorrect >= 75) {
                System.out.println("\nCongratulations, you are ready to go to the next level!");
            } else {
                System.out.println("\nPlease ask your teacher for extra help.");
            }

            System.out.println("\nWould you like to begin a new session?");
            System.out.println("Enter '1' to begin a new session or '0' to quit");
            cont = scnr.nextInt();
        }

    }


}
